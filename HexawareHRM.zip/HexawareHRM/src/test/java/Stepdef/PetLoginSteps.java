package Stepdef;

import Generic.Driverutils;
import PageObjectModel.PetCheckoutPage;
import PageObjectModel.PetLoginPage;
import PageObjectModel.PrtHomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PetLoginSteps {
	
	PetLoginPage plp = new PetLoginPage();
	@Given("Enter URL")
	public void enter_url() {
	    // Write code here that turns the phrase above into concrete actions
		Driverutils.getDriver().get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
	}

	@When("enter valid username {string} and password {string}")
	public void enter_valid_username_and_password(String string, String string2) throws InterruptedException {
		Thread.sleep(5000);
	    plp.verifyEmail(string);
		Thread.sleep(5000);
	    plp.verifyPassword(string2);
	}

	@Then("click login")
	public void click_login() throws InterruptedException {
		Thread.sleep(5000);
	  plp.verifyClick();
	}
	
	PrtHomePage php = new PrtHomePage();
	@When("user navigates to fish category")
	public void user_navigates_to_fish_category() throws InterruptedException {
		Thread.sleep(5000);
		php.VerifyFish();
	  
	 
	}

	@When("user selects a specific fish variety")
	public void user_selects_a_specific_fish_variety() throws InterruptedException {
		Thread.sleep(5000);
		php.VerifyVariety();


	}

	@When("user adds the fish to the cart")
	public void user_adds_the_fish_to_the_cart() throws InterruptedException {
		Thread.sleep(5000);
		php.VerifyAddToCart();


	}
	PetCheckoutPage pcp = new PetCheckoutPage();
	
	@When("user proceed to checkout")
	public void user_proceed_to_checkout() throws InterruptedException {
		Thread.sleep(5000);
		pcp.VerifyProceed();
	   	}

	@When("user cont")
	public void user_cont() throws InterruptedException {
		Thread.sleep(5000);
	   pcp.VerifyCont();
	}

	@When("use confirm")
	public void use_confirm() throws InterruptedException {
		Thread.sleep(5000);
	   pcp.VerifyConfirm();
	}

	//@Then("perform logout")
	//public void perform_logout() {
	
	//}
//
	
	//}


}
