/*package Stepdef;

import Generic.Driverutils;
import PageObjectModel.FrameworkLoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Loginsteps {
	
	FrameworkLoginPage fp = new FrameworkLoginPage();
	@Given("Enter URL")
	public void enter_url() {
	    // Write code here that turns the phrase above into concrete actions
		Driverutils.getDriver().get("https://demowebshop.tricentis.com/login");
	   
	}

	@When("enter valid email {string} and password {string}")
	public void enter_valid_email_and_password(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		fp.verifyEmail(string);
		fp.verifyPassword(string2);
		
	  
	}

	@Then("click login")
	public void click_login() {
		fp.verifyClick();
	    // Write code here that turns the phrase above into concrete actions
	
}}*/