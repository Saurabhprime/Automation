import org.testng.annotations.Test;

public class PriorityNG {
    @Test(priority = 1)
    public void add() {
        System.out.println("this execute before suite");
    }
    
    @Test(priority = 2)
    public void mul() {
        System.out.println("this execute before Test");
    }
    
    @Test(priority = 3)
    public void div() {
        System.out.println("this execute before class");
    }
}
