import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HexD2CaseStd {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		/*driver.get("https://petstore.octoperf.com/actions/Account.action?newAccountForm=");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@name = 'username']")).sendKeys("abc123");
		driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys("Abc123@");
		driver.findElement(By.xpath("//input[@name = 'repeatedPassword']")).sendKeys("Abc123@");
		driver.findElement(By.xpath("//input[@name = 'account.firstName']")).sendKeys("john");
		driver.findElement(By.xpath("//input[@name = 'account.lastName']")).sendKeys("doe");
		driver.findElement(By.xpath("//input[@name = 'account.email']")).sendKeys("jd@gmail.com");
		driver.findElement(By.xpath("//input[@name = 'account.phone']")).sendKeys("9876543210");
		driver.findElement(By.xpath("//input[@name = 'account.address1']")).sendKeys("qwerty");
		driver.findElement(By.xpath("//input[@name = 'account.address2']")).sendKeys("asdf");
		driver.findElement(By.xpath("//input[@name = 'account.city']")).sendKeys("chennai");
		driver.findElement(By.xpath("//input[@name = 'account.state']")).sendKeys("tamilnadu");
		driver.findElement(By.xpath("//input[@name = 'account.zip']")).sendKeys("842001");
		driver.findElement(By.xpath("//input[@name = 'account.country']")).sendKeys("India");
		driver.findElement(By.xpath("//input[@value = 'true']")).click();
		driver.findElement(By.xpath("//input[@name = 'newAccount']")).click();
		*/
		
		
		
	
		
		
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@name = 'username']")).sendKeys("abc123");
		driver.findElement(By.xpath("//input[@name = 'password']")).clear();
		driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys("Abc123@");
		driver.findElement(By.xpath("//input[@value = 'Login']")).click();
		driver.findElement(By.xpath("//a[@href='/actions/Catalog.action?viewCategory=&categoryId=FISH']")).click();
		driver.findElement(By.xpath("//a[text() ='FI-FW-02']")).click();
		driver.findElement(By.xpath("//a[text() ='Add to Cart']")).click();
		
		
		
		
	}

}
