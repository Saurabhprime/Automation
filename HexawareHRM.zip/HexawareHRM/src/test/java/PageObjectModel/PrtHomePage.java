package PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrtHomePage extends BasePage{

	@FindBy(xpath="//a[@href='/actions/Catalog.action?viewCategory=&categoryId=FISH']")
	WebElement fish;
	
	@FindBy(xpath="//a[text() ='FI-FW-02']")
	WebElement variety;
	
	@FindBy(xpath="//a[text() ='Add to Cart']")
	WebElement addtocart;
	
	

	
	
	
	public void VerifyFish() {
		fish.click();
	}
	public void VerifyVariety() {
		variety.click();
	}
	public void VerifyAddToCart() {
		addtocart.click();
	}
	

}
