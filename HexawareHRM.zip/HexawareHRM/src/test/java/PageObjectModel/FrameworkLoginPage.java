package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FrameworkLoginPage extends BasePage {
	@FindBy(name ="Email")
	WebElement txteMail;
	
	@FindBy(name ="Password")
	WebElement txtpassWord;
	
	@FindBy(xpath="//input[@value = 'Log in']")
	
	WebElement input;
	
	
	
	public void verifyEmail(String str) {
		txteMail.sendKeys(str);
	}
	public void verifyPassword(String str) {
		txtpassWord.sendKeys(str);
	}
	
	public void verifyClick() {
		input.click();
	}

}
