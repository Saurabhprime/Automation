package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BlazeBookingsPage extends BasePage{

	@FindBy(id ="inputName")
	WebElement name;
	
	@FindBy(id ="address")
	WebElement address;
	
	@FindBy(id ="city")
	WebElement city;
	
	@FindBy(id ="state")
	WebElement state;
	@FindBy(id ="zipCode")
	WebElement zip;
	
	@FindBy(id ="creditCardNumber")
	WebElement card;
	
	@FindBy(id ="nameOnCard")
	WebElement cardname;
	
	@FindBy(xpath="//input[@class = 'btn btn-primary']")
	
	WebElement buytkt;
	
	
	
	public void verifyName(String str) {
		name.sendKeys(str);
	}
	public void verifyAddress(String str) {
		address.sendKeys(str);
	}
	public void verifyCity(String str) {
		city.sendKeys(str);
	}
	public void verifyState(String str) {
		state.sendKeys(str);
	}
	public void verifyZip(String str) {
		zip.sendKeys(str);
	}
	public void verifyCardInfo(String str) {
		card.sendKeys(str);
	}
	public void verifyCardName(String str) {
		cardname.sendKeys(str);
	}
	
	public void verifyPurchase() {
		buytkt.click();
	}
	
	
	
	
	

}
