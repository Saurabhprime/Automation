package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BlazeHomePage extends BasePage {
	@FindBy(xpath = "(//input[@type='submit'])")

	WebElement searchflight;
	
	@FindBy (xpath ="(//input[@type = 'submit'])")
	WebElement chooseflight;
	

	

	
	

	
	public void VerifyFlightPage() {
		searchflight.click();
	}
	public void SelectFlightPage() {
		chooseflight.click();
	}


}
