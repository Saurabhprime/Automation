package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage extends BasePage {
		
		 @FindBy(xpath="//button[@class='Button-styled__Button-sc-faa870ce-0 eBSxpG Navigation-styled__LogInButton-sc-3ce13586-13 hsBIbz']")
	     WebElement Login;
		 @FindBy(xpath="//button[@class='LoginForm-styled__SignUpLink-sc-be865d4e-0 bXPNHO']")
	    WebElement SignUp;
		 
		 @FindBy(xpath="//input[@id='signup_email']")
		 WebElement Email;
		 
		 @FindBy(xpath="//input[@id='signup_first']")
	    WebElement FirstName;
	    
		 @FindBy(xpath="//input[@id='signup_last']")
		 WebElement LastName;
		 
		 @FindBy(xpath="//input[@id='signup_pass']")
		 WebElement Password;

		 @FindBy(xpath="//button[@class='Button-styled__Button-sc-faa870ce-0 gnkLuW']")
		 WebElement Registration;
		 
	  
		 public void verifyLogIn()
		 {
		 Login.click();
		 }
		 public void verifySignUp()
		 {
		 SignUp.click();
		 }
		 
		 public void verifyEmail(String str)
		 {
		  Email.sendKeys(str);
		 }
		 
		 public void verifyFirstName(String str)
		 {
		  FirstName.sendKeys(str);
		 }
		 public void verifyLastName(String str)
		 {
		  LastName.sendKeys(str);
		 }

		 public void verifyPassword(String str)
		 {
		 Password.sendKeys(str);
		 }

		 public void verifyButton()
		 {
		 Registration.click();
		 }
}



