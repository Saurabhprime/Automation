package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BlazeLoginPage extends BasePage{
	@FindBy(name ="email")
	WebElement email;
	
	@FindBy(name ="password")
	WebElement password;
	
	@FindBy(xpath="//button[@class = 'btn btn-primary']")
	
	WebElement login;
	
	
	
	public void verifyEmail(String str) {
		email.sendKeys(str);
	}
	public void verifyPassword(String str) {
		password.sendKeys(str);
	}
	
	public void verifyClick() {
		login.click();
	}

}
