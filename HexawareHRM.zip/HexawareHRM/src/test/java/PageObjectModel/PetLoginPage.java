package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PetLoginPage extends BasePage {
	
	
	
	
	@FindBy(xpath="//input[@name = 'username']")
	WebElement username;
	
	@FindBy(xpath="//input[@name = 'password']")
	WebElement password;
	
	

	@FindBy(xpath="//input[@value = 'Login']")
	WebElement login;
	
	
	

	public void verifyEmail(String str) {
		username.sendKeys(str);
	}
	public void verifyPassword(String str) throws InterruptedException {
		password.clear();
		Thread.sleep(5000);
		password.sendKeys(str);
	}
	
	public void verifyClick() {
		login.click();
	}

	

}
