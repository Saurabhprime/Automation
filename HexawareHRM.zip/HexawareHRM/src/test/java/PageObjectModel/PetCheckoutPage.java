package PageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PetCheckoutPage extends BasePage{
	@FindBy(xpath="//a[@href='/actions/Order.action?newOrderForm=']")
	WebElement proceed;
	
	@FindBy(xpath="//input[@name ='newOrder']")
	WebElement cont;
	
	@FindBy(xpath="//a[@href='/actions/Order.action?newOrder=&confirmed=true']")
	WebElement confirm;
	
	

	
	
	
	public void VerifyProceed() {
		proceed.click();
	}
	public void VerifyCont() {
		cont.click();
	}
	public void VerifyConfirm() {
		confirm.click();
	}
	

}
