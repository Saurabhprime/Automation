
import org.testng.annotations.Test;

public class Main extends Annotations {
    @Test
    public void verifyTest() {
        System.out.println("executable class");
    }
    
    
   
    public void test1() {
        System.out.println("this execute before Test");
    }
    
}