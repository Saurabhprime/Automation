import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JsHandsOn {

	public static void main(String[] args) throws InterruptedException {
		   System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");

			WebDriver driver=new ChromeDriver();//

			JavascriptExecutor j=(JavascriptExecutor)driver;
				driver.get("https://wisdomtribes.in/");
				driver.manage().window().maximize();
				Thread.sleep(2000);
				String Scrolldown="window.scrollBy(0,4000)";  // for scrol up 
				j.executeScript(Scrolldown);

	}
}
