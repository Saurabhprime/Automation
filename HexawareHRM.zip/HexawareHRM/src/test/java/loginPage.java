import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginPage {
	@FindBy(name ="Email")
	WebElement txteMail;
	
	@FindBy(name ="Password")
	WebElement txtpassWord;
	
	@FindBy(xpath="//input[@value = 'Log in']")
	
	WebElement input;
	
	public loginPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
		
	}
	
	public void verifyEmail(String str) {
		txteMail.sendKeys(str);
	}
	public void verifyPassword(String str) {
		txtpassWord.sendKeys(str);
	}
	
	public void verifyClick() {
		input.click();
	}
	
	
	
	

}
