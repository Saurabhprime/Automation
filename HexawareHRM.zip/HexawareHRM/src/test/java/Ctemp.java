import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ctemp {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://petstore.octoperf.com/actions/Catalog.action");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='Sign In']")).click();
		driver.findElement(By.xpath("//a[text()='Register Now!']")).click();
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("user1");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("abcd1234");
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).sendKeys("abcd1234");
		driver.findElement(By.xpath("//input[@name='account.firstName']")).sendKeys("user");
		driver.findElement(By.xpath("//input[@name='account.lastName']")).sendKeys("123");
		driver.findElement(By.xpath("//input[@name='account.email']")).sendKeys("abc12@gmail.com");
		driver.findElement(By.xpath("//input[@name='account.phone']")).sendKeys("7894561230");
		driver.findElement(By.xpath("//input[@name='account.address1']")).sendKeys("IT Park");
		driver.findElement(By.xpath("//input[@name='account.address2']")).sendKeys("Hockers");
		driver.findElement(By.xpath("//input[@name='account.city']")).sendKeys("Indore");
		driver.findElement(By.xpath("//input[@name='account.State']")).sendKeys("MP");
		driver.findElement(By.xpath("//input[@name='account.zip']")).sendKeys("467008");
		driver.findElement(By.xpath("//input[@name='account.country']")).sendKeys("India");
		driver.findElement(By.xpath("//select[@name='account.languagePreference']")).click();
		driver.findElement(By.xpath("//option[@value='english']")).click();
		driver.findElement(By.xpath("//select[@name='account.favouriteCategoryId']")).click();
		driver.findElement(By.xpath("//option[@value='DOGS']")).click();
		driver.findElement(By.xpath("//input[@name='account.listOption']")).click();
		driver.findElement(By.xpath("//input[@name='account.bannerOption']")).click();
		driver.findElement(By.xpath("//input[@name='newAccount']")).click();

	}

}
