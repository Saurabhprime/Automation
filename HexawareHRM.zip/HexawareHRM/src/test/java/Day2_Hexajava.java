import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Day2_Hexajava {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	/*	driver.get("https://demowebshop.tricentis.com/register");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//label[@for = 'gender-male']")).click();
		driver.findElement(By.xpath("//input[@name = 'FirstName']")).sendKeys("Saurabh");
		driver.findElement(By.xpath("//input[@name = 'LastName']")).sendKeys("Sharma");
		driver.findElement(By.xpath("//input[@name = 'Email']")).sendKeys("r4rbel@gmail.com");
		driver.findElement(By.xpath("//input[@name = 'Password']")).sendKeys("Admin123@");
		driver.findElement(By.xpath("//input[@name = 'ConfirmPassword']")).sendKeys("Admin123@");
		driver.findElement(By.xpath("//input[@name = 'register-button']")).click();
		
		// driver.findElement(By.xpath("//span[text()='PIM']")).click();*/
		
		
		driver.get("https://demowebshop.tricentis.com/login");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@name = 'Email']")).sendKeys("r4rbel@gmail.com");
		driver.findElement(By.xpath("//input[@name = 'Password']")).sendKeys("Admin123@");
		driver.findElement(By.xpath("//input[@value = 'Log in']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Books')]")).click();
		//a[contains(text(),'Electronics')] x path by contains
		
		driver.findElement(By.xpath("//input[@value = 'Add to cart']")).click();
		driver.findElement(By.xpath("//span[text()='Shopping cart']")).click();
		// x path by text
		
		
		

		
		
		

		
	
		
		
		
		
		

	}

}
