package Test;
import PageObjectModel.FrameworkLoginPage;

import org.testng.annotations.Test;

import Generic.Driverutils;

public class FrameworkLoginTest {

	@Test
	public void VerifyLogin() throws InterruptedException{
	Driverutils.getDriver().get("https://demowebshop.tricentis.com/login");
	Thread.sleep(5000);
	FrameworkLoginPage fp = new FrameworkLoginPage();
	fp.verifyEmail("r4rbel@gmail.com");
	fp.verifyPassword("Admin123@");
	fp.verifyClick();
	
	}
}
