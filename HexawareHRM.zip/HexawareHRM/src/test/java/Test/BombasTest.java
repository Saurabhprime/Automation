package Test;

import org.testng.annotations.Test;

import Generic.Driverutils;
import PageObjectModel.BombasHomePage;
import PageObjectModel.BombasPageLogin;

public class BombasTest {
	@Test(priority = 1, alwaysRun = true)
	public void verifyLogin() throws InterruptedException {
	

	BombasPageLogin bp = new BombasPageLogin();
	Driverutils.getDriver().get("https://shop.bombas.com/");
	bp.POP();
	Thread.sleep(5000);
	
	bp.POP2();
	bp.verifyLog();
	bp.verifyEmail("r4rbel@gmail.com");
	bp.verifyPassword("Johndoe123@");
	bp.verifyClick();
	Thread.sleep(5000);
	bp.Pclose();
	Thread.sleep(2000);
	}
	@Test(priority =2 ,enabled = true)
	public void verifyHomepage() throws InterruptedException{
	
	BombasHomePage bh = new BombasHomePage();
	bh.VerifySearchPage();
	bh.VerifySearch("tshirt");
	Thread.sleep(5000);
	bh.VerifyTshirt();
	Thread.sleep(5000);
    bh.VerifyAddToBag();
    Thread.sleep(5000);
	bh.VerifyGoToBag();

}
}