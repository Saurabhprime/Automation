package Test;

import org.testng.annotations.Test;

import Generic.Driverutils;
import PageObjectModel.BlazeBookingsPage;
import PageObjectModel.BlazeHomePage;
import PageObjectModel.BlazeLoginPage;
import PageObjectModel.FrameworkLoginPage;

public class BlazeTest {

	@Test(enabled = false)
	public void VerifyLogin() throws InterruptedException{
	Driverutils.getDriver().get("https://blazedemo.com/login");
	Thread.sleep(5000);
	BlazeLoginPage blp = new BlazeLoginPage();
	blp.verifyEmail("r4rbel@gmail.com");
	blp.verifyPassword("Admin123@");
	blp.verifyClick();
	}
	@Test(enabled =true, priority =1)
	public void  VerifyHomepage() throws InterruptedException {
		Driverutils.getDriver().get("https://blazedemo.com/index.php");
		Thread.sleep(5000);
		BlazeHomePage bhp =new BlazeHomePage();
		bhp.VerifyFlightPage();
		bhp.SelectFlightPage();
	}
	
	@Test(enabled =true, priority =2)
	public void VerifyBookingsPage() throws InterruptedException {
		BlazeBookingsPage bbp = new BlazeBookingsPage();
		bbp.verifyName("saurabh");
		bbp.verifyAddress("Rosa park Sector B");
		bbp.verifyCity("chennai");
		bbp.verifyState("tamilnadu");
		bbp.verifyZip("192021");
		bbp.verifyCardInfo("1234567890");
		bbp.verifyCardName("Sauarbh Sharma");
		Thread.sleep(2000);
		bbp.verifyPurchase();
		
	}

}
