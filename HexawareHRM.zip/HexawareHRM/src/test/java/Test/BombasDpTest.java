package Test;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



import Generic.Driverutils;
import PageObjectModel.BombasHomePage;
import PageObjectModel.BombasPageLogin;
import PageObjectModel.RegistrationPage;

public class BombasDpTest extends Driverutils{
	 @Test(enabled = false)
    public void TestRegPage() throws InterruptedException {
	 RegistrationPage rp = new RegistrationPage();
	 rp.verifyLogIn();
	 rp.verifySignUp();
	 rp.verifyEmail("r4rbel@gmail.com");
	 rp.verifyFirstName("John");
	 rp.verifyLastName("Doe");
	 rp.verifyPassword("Johndoe123@");
	 rp.verifyButton();
	 Thread.sleep(30000);
 }
 @DataProvider
 public Object[][] getData()
	{
		Object[][] Data=new Object[1][2];
		Data[0][0]="r4rbel@gmail.com";
		Data[0][1]="Johndoe123@";
		return Data;
	}
	@Test(dataProvider="getData",priority = 1)
	public void test(String user,String password) throws InterruptedException
	{
		BombasPageLogin bp = new BombasPageLogin();
		Driverutils.getDriver().get("https://shop.bombas.com/");
		Thread.sleep(5000);
		Driverutils.getDriver().manage().window().maximize();
		Driverutils.getDriver().findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 PjsOG AlertDialog-styled__Button-sc-849264eb-1 hsBkBg']")).click();
		Thread.sleep(5000);
		Driverutils.getDriver().findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 beIcGJ CouponDialog-styled__ButtonLink-sc-ab66e97d-11 fQqSFt']")).click();
	
		bp.verifyLog();
		bp.verifyEmail("r4rbel@gmail.com");
		bp.verifyPassword("Johndoe123@");
		bp.verifyClick();
		Thread.sleep(7000);
		bp.Pclose();
		Thread.sleep(2000);
		Reporter.log(user + " " + password,true);

	
		
		
	}
 

		
	
	
	@Test(dependsOnMethods={"test"}, priority = 2,alwaysRun = true)
	public void TestSearch() throws InterruptedException {
		BombasHomePage bh = new BombasHomePage();
		Thread.sleep(5000);
		bh.VerifySearchPage();
		Thread.sleep(2000);
		bh.VerifySearch("tshirt");
		Thread.sleep(2000);
		bh.VerifyTshirt();
		Thread.sleep(2000);
		bh.VerifyAddToBag();
	}

 
@Test(dependsOnMethods={"test"},priority =3, enabled = true)
	public void TestCart() throws InterruptedException {
	BombasHomePage bh = new BombasHomePage();
		Thread.sleep(5000);
		bh.VerifyGoToBag();;


}


}
