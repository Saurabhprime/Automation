package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.Reporter;

public class DpBombas {

    @DataProvider(name = "loginData")
    public Object[][] getData() {
    	Object[][] Data=new Object[2][2];
		Data[0][0]="r4rbel@gmail.com";
		Data[0][1]="Johndoe123@";
		Data[1][0]="userxyz@gmail.com";
		Data[1][1]="Wherisuser";

        return Data;
         
        };
    

    @Test(dataProvider = "loginData")
    public void login(String username, String password) throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://shop.bombas.com/");
		Actions act = new Actions (driver);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 PjsOG AlertDialog-styled__Button-sc-849264eb-1 hsBkBg']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 beIcGJ CouponDialog-styled__ButtonLink-sc-ab66e97d-11 fQqSFt']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 eBSxpG Navigation-styled__LogInButton-sc-3ce13586-13 hsBIbz']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id = 'login_email']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@id = 'login_pass']")).sendKeys(password);
		driver.findElement(By.xpath("//button[@class = 'Button-styled__Button-sc-faa870ce-0 gnkLuW']")).click();
        Reporter.log(username + " and password: " + password, true);
        Thread.sleep(5000);

    
        
  
    }
}
