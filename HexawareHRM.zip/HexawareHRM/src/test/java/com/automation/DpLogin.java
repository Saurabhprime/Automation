package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.Reporter;

public class DpLogin {

    @DataProvider(name = "loginData")
    public Object[][] getData() {
    	Object[][] Data=new Object[2][2];
		Data[0][0]="Admin";
		Data[0][1]="admin123";
		Data[1][0]="xyz";
		Data[1][1]="abc";

        return Data;
         
        };
    

    @Test(dataProvider = "loginData")
    public void login(String username, String password) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@name = 'username']")).sendKeys((username));
        driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys((password));
        driver.findElement(By.xpath("//button[@type = 'submit']")).click();
        Reporter.log(username + " and password: " + password, true);
        Thread.sleep(5000);
  
    }
}
