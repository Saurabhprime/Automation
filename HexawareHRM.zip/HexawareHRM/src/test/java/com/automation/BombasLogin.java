package com.automation;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BombasLogin {
	@Test
	@Parameters({"a", "b"})
	public void login(String c,String d) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://shop.bombas.com/");
		Actions act = new Actions (driver);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 PjsOG AlertDialog-styled__Button-sc-849264eb-1 hsBkBg']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 beIcGJ CouponDialog-styled__ButtonLink-sc-ab66e97d-11 fQqSFt']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 eBSxpG Navigation-styled__LogInButton-sc-3ce13586-13 hsBIbz']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id = 'login_email']")).sendKeys(c);
		driver.findElement(By.xpath("//input[@id = 'login_pass']")).sendKeys(d);
		driver.findElement(By.xpath("//button[@class = 'Button-styled__Button-sc-faa870ce-0 gnkLuW']")).click();
	}
	

}
