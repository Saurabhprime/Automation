package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PriorityBombas {

    
    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][] {
            {"r4rbel@gmail.com", "Johndoe123@", "Women's Solids Ankle Sock 4-Pack"}
        };
    }

    @Test(dataProvider = "loginData")
    public void testBombasShop(String email, String password, String searchItem) throws InterruptedException {

    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://shop.bombas.com/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
        driver.findElement(By.xpath("//button [text()='Got It']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button [text()='Log In']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//span[@data-name='close']) [2]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//input[@type='email']) [2]")).sendKeys(email);
        driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//button[@type='submit']) [2]")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("(//span[@data-name='close']) [2]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//span[@size='22']) [2]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='search']")).sendKeys(searchItem);
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//img[@alt=\"" + searchItem + "\"]) [2]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button [text()='Add to Bag']")).click();
    }
}

/*Thread.sleep(1000);
driver.findElement(By.xpath("(//button(@type='submit']) [2]")).click();
Thread.sleep(4000);
driver.findElement(By.xpath("(//span[@data-name='close']) [2]")).click();
Thread.sleep(3000);
driver.findElement(By.xpath("(//span[@size='22']) [2]")).click();
Thread.sleep(1000);
driver.findElement(By.xpath("//input[@id='search']")).sendKeys(z);
Thread.sleep(2000);
//driver.findElement(By.xpath("(//span[@data-name='close'])[2]")).click();
// Thread.sleep(1000);
driver.findElement(By.xpath("(//img[@alt=\"Women's Solids Ankle Sock 4-Pack\"]) [2]")).click();
Thread.sleep(1000);
driver.findElement(By.xpath("//button [text()='Add to Bag']")).click();
}*/