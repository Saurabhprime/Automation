package com.automation;

public class BombasRegisterPage {

}
