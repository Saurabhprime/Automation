package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class BombasLoginPage {
	
	
	@FindBy(xpath="//button[@class='Button-styled__Button-sc-faa870ce-0 PjsOG AlertDialog-styled__Button-sc-849264eb-1 hsBkBg']")
	WebElement PC1;
	
	@FindBy(xpath="//button[@class='Button-styled__Button-sc-faa870ce-0 beIcGJ CouponDialog-styled__ButtonLink-sc-ab66e97d-11 fQqSFt']")
	WebElement PC2;
	
	
	@FindBy(xpath="//button[@class='Button-styled__Button-sc-faa870ce-0 eBSxpG Navigation-styled__LogInButton-sc-3ce13586-13 hsBIbz']")
	WebElement Login;
	
	@FindBy(xpath="//input[@id = 'login_email']")
	WebElement txteMail;
	
	@FindBy(xpath="//input[@id = 'login_pass']")
	WebElement txtpassWord;
	
	
	@FindBy(xpath="//button[@class = 'Button-styled__Button-sc-faa870ce-0 gnkLuW']")
	
	
	WebElement input;
	
	@FindBy(xpath="(//span[@data-name='close'])[2]")

	
	
	WebElement PC3;
	
	
	
	public BombasLoginPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
		
	}
	
	
	public void POP() {
		PC1.click();
	}
	public void POP2() {
		PC2.click();
	}
	
	public void verifyLog() {
		Login.click();
	}
	
	
	public void verifyEmail(String str) {
		txteMail.sendKeys(str);
	}
	public void verifyPassword(String str) {
		txtpassWord.sendKeys(str);
	}
	
	public void verifyClick() {
		input.click();
	}
	
	public void Pclose() {
		PC3.click();
	}
	
	
	
	

}
