package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BombasHomePage {
	
	@FindBy (xpath ="(//button[@aria-label = 'Search'])[2]")
	WebElement searchpage;
	
	@FindBy (xpath ="(//input[@type = 'text'])[1]")
	WebElement search;
	
	@FindBy (xpath ="(//a[@href= 'https://bombas.com/products/mens-pima-cotton-crew-neck-t-shirt?variant=white'])[2]")
	WebElement searchtshirt;
	
	@FindBy (xpath ="//button[@class='Button-styled__Button-sc-faa870ce-0 ctBnsh ProductDetails-styled__AddToBagButton-sc-ced5d4a3-14 dzspSE']")
	WebElement addtobag;
	
	@FindBy (xpath ="//a[@href= 'https://bombas.com/cart']")
	WebElement gotobag;
	
	

	
	
	
		
	
	
	public void VerifySearchPage() {
		searchpage.click();
	}
	public void VerifySearch(String str) {
		search.sendKeys(str);
	}
	public void VerifyTshirt() {
		searchtshirt.click();
	}
	public void VerifyAddToBag() {
		addtobag.click();
	} 
	
	public void VerifyGoToBag() {
		gotobag.click();
	} 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//public void verifyEmail(String str) {
	//	txteMail.sendKeys(str);
	//}
	//public void verifyPassword(String str) {
	//	txtpassWord.sendKeys(str);
	///}
	
	//public void verifyClick() {
	//	input.click();
	//}
	
	

}
