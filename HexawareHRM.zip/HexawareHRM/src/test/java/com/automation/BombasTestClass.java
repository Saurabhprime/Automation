package com.automation;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class BombasTestClass  extends BombasAnnotations{
	/* @Test(enabled = false)
        public void TestRegPage() throws InterruptedException {
    	 BombasRegisterPage rp = new BombasRegisterPage(driver);
    	 rp.VerifyLogInPage();
    	 rp.VerifySignUpPage();
    	 rp.VerifyEmail("r4rbel@gmail.com");
    	 rp.VerifyfirstName("John");
    	 rp.VerifylastName("Doe");
    	 rp.VerifyPassword("Johndoe123@");
    	 rp.VerifySignUpButton();
    	 Thread.sleep(30000);
    	 rp.VerifyConfirm();
     }*/
     @DataProvider
     public Object[][] getData()
 	{
 		Object[][] Data=new Object[1][2];
 		Data[0][0]="r4rbel@gmail.com";
 		Data[0][1]="Johndoe123@";
 		return Data;
 	}
 	@Test(dataProvider="getData",priority = 1)
 	public void test(String user,String password) throws InterruptedException
 	{
 	
 		driver.findElement(By.xpath("//button[text() = 'Log In']")).click();
 		Thread.sleep(2000);
 		driver.findElement(By.xpath("(//input[@class = 'FormInput-styled__Input-sc-50fe01d5-0 ePHBHg'])[2]")).sendKeys(user);
 		Thread.sleep(2000);
 		driver.findElement(By.xpath("//input[@id = 'login_pass']")).sendKeys(password);
 		Thread.sleep(2000);
 		driver.findElement(By.xpath("//button[@class = 'Button-styled__Button-sc-faa870ce-0 gnkLuW']")).click();
 		Reporter.log(user + " " + password,true);
 		Thread.sleep(20000);
 		driver.findElement(By.xpath("//button[@aria-label = 'close account nav']")).click();
 		
 		
 	}
     
 
 		
 	
 	
 	@Test(priority = 2,alwaysRun = true)
 	public void TestSearch() throws InterruptedException {
 		BombasHomePage bh = new BombasHomePage(driver);
 		Thread.sleep(2000);
 		bh.VerifySearchPage();
 		Thread.sleep(2000);
 		bh.VerifySearch("tshirt");
 		Thread.sleep(2000);
 		bh.VerifyTshirt();
 		Thread.sleep(2000);
 		bh.VerifyAddToBag();
 	}

     
	@Test(priority =3, enabled = true)
 	public void TestCart() throws InterruptedException {
		BombasHomePage bh = new BombasHomePage(driver);
 		Thread.sleep(5000);
 		bh.VerifyGoToBag();;
	

}

}
