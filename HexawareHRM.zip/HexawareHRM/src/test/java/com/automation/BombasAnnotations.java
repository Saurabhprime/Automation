package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class BombasAnnotations {
	WebDriver driver;
	@BeforeSuite
	public void test() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		driver = new ChromeDriver();	
	}
	@BeforeTest
	public void test1() throws InterruptedException
	{
		driver.get("https://shop.bombas.com/");
		Thread.sleep(5000);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 PjsOG AlertDialog-styled__Button-sc-849264eb-1 hsBkBg']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@class='Button-styled__Button-sc-faa870ce-0 beIcGJ CouponDialog-styled__ButtonLink-sc-ab66e97d-11 fQqSFt']")).click();
	
		
	}
	@BeforeClass
	public void test2()
	{
		System.out.println("this execute before class");
	}
	@BeforeMethod
	public void test3()
	{
		System.out.println("this execute before method");
	}
    @AfterSuite
	public void test4() throws InterruptedException
	{
    	Thread.sleep(5000);
    	driver.quit();
		System.out.println("webpage closed");
	}
	@AfterTest
	public void test5()
	{
		System.out.println("this execute after Test");
	}
	@AfterClass
	public void test6()
	{
		System.out.println("this execute after class");
	}
	@AfterMethod
	public void test7()
	{
		System.out.println("this execute after method");
	}
 


}


