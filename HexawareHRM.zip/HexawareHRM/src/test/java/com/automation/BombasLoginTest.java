package com.automation;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BombasLoginTest {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		BombasLoginPage bp = new BombasLoginPage(driver);
		driver.get("https://shop.bombas.com/");
		driver.manage().window().maximize();
		bp.POP();
		Thread.sleep(5000);
		
		bp.POP2();
		bp.verifyLog();
		bp.verifyEmail("r4rbel@gmail.com");
		bp.verifyPassword("Johndoe123@");
		bp.verifyClick();
		Thread.sleep(5000);
		bp.Pclose();
		Thread.sleep(2000);
		
		BombasHomePage bh = new BombasHomePage(driver);
		bh.VerifySearchPage();
  	    bh.VerifySearch("tshirt");
  		Thread.sleep(5000);
  	    bh.VerifyTshirt();
  		Thread.sleep(5000);
  	    bh.VerifyAddToBag();
  	    Thread.sleep(5000);
  	    bh.VerifyGoToBag();
 
  	   
		//bh.verifyBar();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	//	CartPage cp =new CartPage(driver);
	//	cp.verifyClick();
	//	JavascriptExecutor j=(JavascriptExecutor)driver;
	//	String Scrolldown="window.scrollBy(0,200)";  // for scrol up 
	//	j.executeScript(Scrolldown);
	//	Thread.sleep(5000);
	//	String Scrollup="window.scrollBy(0,-1000)";  // for scrol up 
	//	j.executeScript(Scrollup);
	//	Thread.sleep(5000);
		

	//	cp.vClick();
	///	cp.idClick();
	//	cp.clClick();
	///	Thread.sleep(2000);
	//	cp.lClick();

	}

}
