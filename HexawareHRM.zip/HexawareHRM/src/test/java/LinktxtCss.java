import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinktxtCss{

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

    
        driver.get("https://demowebshop.tricentis.com/login");
        Thread.sleep(5000);

       
        driver.findElement(By.xpath("//input[@name='Email']")).sendKeys("r4rbel@gmail.com");
        driver.findElement(By.xpath("//input[@name='Password']")).sendKeys("Admin123@");
        driver.findElement(By.xpath("//input[@value='Log in']")).click();

        
        driver.findElement(By.linkText("Books")).click();
        driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
       driver.findElement(By.cssSelector("span.cart-label")).click();
       driver.findElement(By.partialLinkText("Electronics")).click();

    }
}
