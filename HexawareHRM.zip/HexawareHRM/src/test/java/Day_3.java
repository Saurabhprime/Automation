import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Day_3 {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		WebElement drag = driver.findElement(By.xpath("//button[text() = 'Double-Click Me To See Alert']"));
		
		TakesScreenshot t = (TakesScreenshot)driver;
		File src = t.getScreenshotAs(OutputType.FILE);
		File dest = new File("C:\\Users\\saura\\OneDrive\\Documents\\Screenshot.png");
		FileUtils.copyFile(src , dest);
		
	//	Actions act = new Actions (driver);
	//	act.doubleClick(drag).perform();
		//Alert a = driver.switchTo().alert();  //  Alert javascript interface for popups and notifications
		//System.out.println(a.getText());        // print text written in pop up
	//	a.accept();							// for accepting pop up
		//a.dismiss();                        // for rejetinh
		//sendKeys(keysToEnter)  //: To enter some text on the popup/alert's input bo

		
		
		
		
		
		
	//	driver.get("https://demowebshop.tricentis.com/books?orderby=15");
		//WebElement element = driver.findElement(By.xpath("(//a[contains(text(), 'Computers')])[1]"));
		//Actions act = new Actions(driver);
	//	act.moveToElement(element).perform();
	//	act.contextClick(element).perform();
	//	act.doubleClick(element).perform();
	//	
		
		
		
		//driver.findElement(By.xpath("//a[contains(text(),'Desktops')]")).click();
		
		
		
		
		
		
	//Multiple select demo
	//	driver.get("file:///C:/Users/saura/Desktop/handson.html");
	//	WebElement element = driver.findElement(By.xpath("//select[@id ='slv']"));
	//	Select el = new Select(element);
	//	el.selectByIndex(3);
	//	Thread.sleep(5000);
	//	el.deselectAll();
		
		
		
		//driver.get("https://demowebshop.tricentis.com/books");
	//	Thread.sleep(5000);
	//	WebElement  element = driver.findElement(By.id("products-orderby"));
		
		//Select check = new Select(element);
		//check.selectByIndex(3);
		//check.selectByVisibleText("Created on");
		//check.selectByValue("https://demowebshop.tricentis.com/books?orderby=5");
		
	//	List<WebElement> el = check.getOptions();
	//	int count = el.size();
	//	System.out.println(count);
	//	for(int i =0; i<count; i++) {
	//		System.out.println(el.get(i).getText());
	//	}
		
		
		
		
		

	}

}
