import org.testng.annotations.Test;

public class DependedTest {
	
    @Test(groups = "Common")
    public void add() {
        System.out.println("this execute before suite");
    }
    
    @Test(groups = "Common")
    public void mul() {
        System.out.println("this execute before Test");
    }
    
    @Test(dependsOnGroups = "Common")
    public void div() {
        System.out.println("this execute before class");
    }
}
