import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ElementSelected {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        try {
            driver.get("https://demowebshop.tricentis.com/books");
            Thread.sleep(5000);

            WebElement element = driver.findElement(By.id("products-orderby"));
            Select check = new Select(element);
            check.selectByVisibleText("Created on");

            WebDriverWait wait = new WebDriverWait(driver, 5);
            wait.until(ExpectedConditions.elementToBeSelected(By.xpath("//option[@selected='selected' and text()='Created on']")));
            System.out.println("loaded");
            
        } catch (Exception e) {
            System.out.println("not clicked");
        } 
  
    }
}
