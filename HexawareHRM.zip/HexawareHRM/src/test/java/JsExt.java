import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JsExt {

	public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");

		WebDriver driver=new ChromeDriver();//

		JavascriptExecutor j=(JavascriptExecutor)driver;
			//driver.get("https://www.selenium.dev/downloads/");
			driver.get("file:///C:/Users/saura/Desktop/jsdmo.html");
			driver.manage().window().maximize();
			Thread.sleep(2000);
		//	String Scrolldown="window.scrollBy(0,5000)";  // for scrol up an down
		//	j.executeScript(Scrolldown);
		//	Thread.sleep(2000);
		//	String Scrollup="window.scrollBy(0,-5000)";
		//	j.executeScript(Scrollup); 
			
		
		/*	String stmt=	"document.getElementById('n').value='SAURABH'";
			j.executeScript(stmt);
			Thread.sleep(10000);
			String stmt1=	"document.getElementById('n').value=''";
			j.executeScript(stmt1);
			String stmt2="document.getElementById('g').click()";
			j.executeScript(stmt2);*/

	}

}
