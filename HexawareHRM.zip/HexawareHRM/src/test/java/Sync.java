import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Sync{

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		WebElement drag = driver.findElement(By.xpath("//button[text() = 'Double-Click Me To See Alert']"));
		Actions a = new Actions (driver);
		a.doubleClick(drag).perform();
		TakesScreenshot t = (TakesScreenshot)driver;
		Alert a1 = driver.switchTo().alert();
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			System.out.println(a1.getText());
			System.out.println("PAge Loded");
			a1.dismiss();
			
			
			
			
		} 
		catch(Exception E) {
			System.out.println("alert not loaded");
		}
		
		File src = t.getScreenshotAs(OutputType.FILE);
		File dest = new File("C:\\Users\\saura\\OneDrive\\Documents\\Screenshot0.png");
		FileUtils.copyFile(src , dest);
	}
}
		






















