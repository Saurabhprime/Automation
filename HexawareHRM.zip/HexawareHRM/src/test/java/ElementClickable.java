import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ElementClickable {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		WebElement drag= driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Actions act=new Actions(driver);
		Thread.sleep(1000);
		WebDriverWait wait= new WebDriverWait(driver, 5);
		WebElement element=driver.findElement(By.xpath("//a[text()='Bank Project']"));
		try {
			wait.until(ExpectedConditions.elementToBeClickable(element));
			System.out.println(element.getText());
			System.out.println("Element successfully clicked"); 
		}
		catch(Exception e) {
			System.out.println("Failed");
		}
	}
	}