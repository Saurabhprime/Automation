import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        
            driver.get("https://www.amazon.in/");
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Samsung");
            Thread.sleep(3000);
            
            // Adjusted XPath to match the provided HTML structure
            List<WebElement> li = driver.findElements(By.xpath("//div[contains(text(),'Samsung')]"));
         	Thread.sleep(3000);
            
            int count = li.size();
         	Thread.sleep(3000);
            System.out.println(count);
            for (WebElement element : li) {
            	Thread.sleep(3000);
                System.out.println(element.getText());
            }
       
    
}

}