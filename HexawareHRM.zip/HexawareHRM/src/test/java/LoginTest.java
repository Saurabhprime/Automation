import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/login");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		loginPage lp = new loginPage(driver);
		lp.verifyEmail("r4rbel@gmail.com");
		lp.verifyPassword("Admin123@");
		lp.verifyClick();
		Thread.sleep(2000);
		BooksPage bp = new BooksPage(driver);
		bp.verifyClick();
		Thread.sleep(2000);
		CartPage cp =new CartPage(driver);
		cp.verifyClick();
		JavascriptExecutor j=(JavascriptExecutor)driver;
		String Scrolldown="window.scrollBy(0,200)";  // for scrol up 
		j.executeScript(Scrolldown);
		Thread.sleep(5000);
		String Scrollup="window.scrollBy(0,-1000)";  // for scrol up 
		j.executeScript(Scrollup);
		Thread.sleep(5000);
		

		cp.vClick();
		cp.idClick();
		cp.clClick();
		Thread.sleep(2000);
		cp.lClick();
	}

}
