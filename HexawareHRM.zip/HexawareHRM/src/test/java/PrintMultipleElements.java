import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PrintMultipleElements {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
	        WebDriver driver = new ChromeDriver();
	        driver.get("https://www.google.co.in/");
	        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	        driver.findElement(By.name("q")).sendKeys("QSpiders");
	        Thread.sleep(3000);
	        
	       List<WebElement> li = driver.findElements(By.xpath("//span[contains(text(),'QSpiders')]"));
	       
	       Thread.sleep(3000);
	       int count = li.size();
	       Thread.sleep(3000);
	       System.out.println(count);
	       for (int i =0; i<count; i++) {
	    	   Thread.sleep(3000);
	    	 System.out.println(li.get(i).getText());
	       }
	}

}
