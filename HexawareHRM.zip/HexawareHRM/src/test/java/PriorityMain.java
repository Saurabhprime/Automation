import org.testng.annotations.Test;

public class PriorityMain {
    @Test(alwaysRun = true)
    public void add() {
        System.out.println("this execute before suite");
    }
    
    @Test(enabled = false)
    public void mul() {
        System.out.println("this execute before Test");
    }
    
    @Test(enabled = true)
    public void div() {
        System.out.println("this execute before class");
    }
}
