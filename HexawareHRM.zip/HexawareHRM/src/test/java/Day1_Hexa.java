import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Day1_Hexa {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	
		
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			Thread.sleep(5000);
			
			driver.findElement(By.xpath("//input[@name = 'username']")).sendKeys("Admin");
			driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys("admin123");
			driver.findElement(By.xpath("//button[@type = 'submit']")).click();
			driver.findElement(By.xpath("//span[text()= 'Admin']")).click();
			
		
			
		
		
		
			
			
			
			
			//xpath by text:
			 //tagname[text()='value']

		//	span[text()='Admin'];
		
		
		
	
		
	/*	driver.manage().window().maximize();
	System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getPageSource());
		driver.navigate().to("https://www.google.co.in/");
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		driver.close();    */
		
		
		
		
		

	}
}
