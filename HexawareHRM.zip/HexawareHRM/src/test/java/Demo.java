import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saura\\Desktop\\HexawareHRM\\src\\test\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	
		
			driver.get("https://qa.inseego5g.net");
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys("qa_admin");
			driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys("Qua!it^&7%23");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//i[@class='icon device']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@class='show']")).sendKeys("V2000-95f9");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[@class='search-btn']")).click();
			
			
			
			
			
		
		

	}
}
